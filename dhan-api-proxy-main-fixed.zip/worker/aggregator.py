# TODO: build rolling 1m bars (OHLCV) from ticks if needed
